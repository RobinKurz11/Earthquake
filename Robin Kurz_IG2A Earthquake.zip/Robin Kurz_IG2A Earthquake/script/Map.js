var paper;
var data_Erdbeeben;
var paper = Snap("#svgContainer");
var paperWidth = document.getElementById("svgContainer").getAttribute("width");
var paperHeight = document.getElementById("svgContainer").getAttribute("height");
var box = document.getElementById("svgContainer").getBoundingClientRect();
var xOffset = box.left;
var yOffset = box.top;
var lastMouseY = 0;
var paperWidth = window.innerWidth;
var paperHeight = window.innerHeight;
var box1;
var box2;
var box3;
var box2b;
var animationDuration = 500;
var mapcolors = chroma.scale(['#C3C28E','#FF0000']).mode('lch').colors(5);

init();

function init() {
    drawMap();
}

//----------------1. Hoverrechteck----------------
var box1 = paper.rect(0,10,paperWidth/3,paperHeight).attr({
  fill: "white",
  opacity: 0
});

var indicatorBox1 = paper.rect(0,0,paperWidth/3,10).attr({
  fill:"white",
  opacity: 0
});

box1.mouseover(function(){
  indicatorBox1.animate({
    opacity: 0.5
  },1);
  box1.animate({
    opacity: 0.015
  },1);
});
box1.mouseout(function(){
  indicatorBox1.animate({
    opacity: 0
  },1);
  box1.animate({
    opacity: 0
  },1);
});

box1.click(goBack);



//----------------2. Hoverrechteck----------------
var box2 = paper.rect(paperWidth/3,10,paperWidth/3,paperHeight).attr({
  fill: "white",
  opacity: 0
});

var box2b = paper.rect(paperWidth/3,0,paperWidth/3,10).attr({
  fill:"white",
  opacity: 0
});

box2.click(goToTop2);



//----------------Hover Box 2----------------
box2.mouseover(function(){
  box2b.animate({
    opacity: 0.5
  },1);
}).mouseout(function(){
  box2b.animate({
    opacity: 0
  },1);
})

box2.mouseover(function(){
  box2.animate({
    opacity: 0.015
  },1);
}).mouseout(function(){
  box2.animate({
    opacity: 0
  },1);
})


//----------------3. Hoverrechteck----------------
var box3 = paper.rect(paperWidth/1.5,10,paperWidth/3,paperHeight).attr({
  fill: "white",
  opacity: 0
});

var box3b = paper.rect(paperWidth/1.5,0,paperWidth/3,10).attr({
  fill:"white",
  opacity: 0
});

box3.click(makeDepth1);




//----------------Hover Box 3----------------
box3.mouseover(function(){
  box3b.animate({
    opacity: 0.5
  },1);
}).mouseout(function(){
  box3b.animate({
    opacity: 0
  },1);
})

box3.mouseover(function(){
  box3.animate({
    opacity: 0.015
  },1);
}).mouseout(function(){
  box3.animate({
    opacity: 0
  },1);
})




//----------------------------------Map zeichnen--------------------------------


function drawMap() {
    for (let i = 0; i < data.length; i++) {
        data[i].xPos = map(data[i].Longitude, -180, 180, 0, paperWidth);
        data[i].yPos = map(data[i].Latitude, -90, 90, 0, paperHeight);
        data[i].radius = 1;
        data[i].circle = paper.ellipse(data[i].xPos, paperHeight - data[i].yPos, 1,1);

        var colindex = map(data[i].Magnitude, 5, 7.5, 0, 4);
        colindex = Math.floor(colindex);
        if (colindex > 5) colindex = 5;

        data[i].circle.attr({
          fill: mapcolors[colindex],
          opacity: map(data[i].Magnitude, 5, 7.5, 0.1, 1)
        })
      }
}


//************************************Map zeichnen**********************************

var goToTopDone2 = false;

function goToTop2() {
  if(!goToTopDone2) {
  for (let i=0; i < data.length; i++) {
    data[i].circle.animate({
      cy:paperHeight/2
    }, animationDuration, mina.easeinout, drawLine);
  }
  goToTopDone2 = true;
}
}

var drawlineDone = false;

function drawLine() {
  if (!drawlineDone) {
    for (var i = 0; i < data.length; i++) {
      data[i].circle.animate({
        ry:(data[i].Magnitude*80)-400
      }, animationDuration, mina.easeinout, reactivateTop);
    }
    drawlineDone = true;
  }

}

var goBackDone = false;

function goBack(){
  if (!goBackDone) {
  for (var i = 0; i < data.length; i++) {
    data[i].circle.animate({
      ry:1
    }, animationDuration, mina.bounce,goBack2);
  }
  goBackDone = true;
}
}

var goBackDone2 = false;

function goBack2(){
  if (!goBackDone2) {
  for (var i = 0; i < data.length; i++) {
    data[i].circle.animate({
      cy:paperHeight-data[i].yPos
    }, animationDuration,mina.easeInOut,reactivateBack);
  }
  goBackDone2 = true;
}
}

var makeDepthDone1 = false;

function makeDepth1(){
  if(!makeDepthDone1) {
    for (var i = 0; i < data.length; i++) {
      data[i].circle.animate({
        ry: 1
      }, animationDuration, mina.easeinout, makeDepth2)
    }
    makeDepthDone1 = true;
  }
}

var makeDepthDone2 = false;

function makeDepth2(){
  if(!makeDepthDone2) {
    for (var i = 0; i < data.length; i++) {
      data[i].circle.animate({
        cy:10
    }, animationDuration, mina.easeinout, makeDepth3)
    }
    makeDepthDone2 = true;
  }
}

var makeDepthDone3 = false;

function makeDepth3(){
  if(!makeDepthDone3) {
    for (var i = 0; i < data.length; i++) {
      data[i].circle.animate({
        cy:data[i].Depth+10
    }, animationDuration, mina.bounce, reactivateDepth)
    }
    makeDepthDone3 = true;
  }
}


function reactivateTop() {
  if (goToTopDone2 && drawlineDone){
   goToTopDone2=false;
   drawlineDone=false;
 }
}

function reactivateBack() {
  if (goBackDone && goBackDone2) {
    goBackDone = false;
    goBackDone2 = false;
  }
}

function reactivateDepth() {
  if (makeDepthDone1 && makeDepthDone2 && makeDepthDone3) {
    makeDepthDone1 = false;
    makeDepthDone2 = false;
    makeDepthDone3 = false;
  }
}

function areaToRadius(input) {
    return Math.sqrt(input / Math.PI);
}
